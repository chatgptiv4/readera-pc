import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Grid, List, Star, Trash2, BookOpen, FolderOpen, RefreshCw } from 'lucide-react'
import { useAppStore } from '../../store/appStore'
import { generateMissingCovers } from '../../utils/coverGenerator'
import LibrarySwitcher from '../LibrarySwitcher'
import BookCard from './BookCard'

const STATUS_FILTERS = [
  { label: 'All', value: '' },
  { label: 'Reading', value: 'reading' },
  { label: 'Unread', value: 'unread' },
  { label: 'Finished', value: 'finished' },
]

const FAVOURITES_VALUE = '__favourites__'

const FORMAT_FILTERS = ['', 'PDF', 'EPUB', 'MOBI', 'TXT', 'DOCX']

export default function LibraryPage() {
  const navigate = useNavigate()
  const {
    books, booksLoading, loadBooks,
    searchQuery, setSearch,
    filterStatus, filterFormat, setFilter,
    sortBy, setSortBy,
    updateBook, deleteBook,
  } = useAppStore()

  const [viewMode, setViewMode] = useState('grid') // 'grid' | 'list'
  const [scanning, setScanning] = useState(false)
  const [favouritesOnly, setFavouritesOnly] = useState(false)
  const [allTags, setAllTags] = useState([])
  const [activeTag, setActiveTag] = useState('')

  useEffect(() => {
    loadBooks()
    fetch('/api/tags').then(r => r.json()).then(setAllTags).catch(() => {})
  }, [])

  // Quietly generate real cover thumbnails in the background for any book that's missing one
  useEffect(() => {
    if (books.length === 0) return
    generateMissingCovers(books, () => loadBooks())
  }, [books.length])

  const displayedBooks = books
    .filter(b => !favouritesOnly || b.is_favourite)
    .filter(b => !activeTag || (() => { try { return JSON.parse(b.tags || '[]').includes(activeTag) } catch { return false } })())

  const handleScan = async () => {
    setScanning(true)
    try {
      const settings = await fetch('/api/settings').then(r => r.json())
      const folders = settings.watch_folders || []
      if (!folders.length) {
        alert('No watch folders configured. Go to Settings → Library Folders to add one.')
        return
      }
      for (const f of folders) {
        const folderPath = typeof f === 'string' ? f : f.path
        const libraryId = typeof f === 'string' ? 1 : (f.libraryId || 1)
        await fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ folder: folderPath, library_id: libraryId }) })
      }
      await loadBooks()
    } finally {
      setScanning(false)
    }
  }

  return (
    <>
      {/* Topbar */}
      <div className="topbar">
        <LibrarySwitcher />

        <div className="search-bar">
          <Search size={16} />
          <input
            placeholder="Search books, authors…"
            value={searchQuery}
            onChange={e => setSearch(e.target.value)}
          />
          {searchQuery && (
            <button className="btn-ghost btn-sm btn-icon" onClick={() => setSearch('')}>✕</button>
          )}
        </div>

        <select className="select-input" value={sortBy} onChange={e => setSortBy(e.target.value)}>
          <option value="date_added">Recently Added</option>
          <option value="title">Title A–Z</option>
          <option value="author">Author A–Z</option>
          <option value="last_opened">Recently Opened</option>
        </select>

        <div style={{ flex: 1 }} />

        <button className={`btn btn-secondary btn-icon btn-sm`} onClick={() => setViewMode(v => v === 'grid' ? 'list' : 'grid')} title="Toggle view">
          {viewMode === 'grid' ? <List size={16} /> : <Grid size={16} />}
        </button>

        <button className="btn btn-secondary btn-sm" onClick={handleScan} disabled={scanning}>
          <RefreshCw size={14} className={scanning ? 'spin' : ''} />
          {scanning ? 'Scanning…' : 'Scan'}
        </button>
      </div>

      {/* Filter bar */}
      <div style={{ padding: '12px 20px', borderBottom: '1px solid var(--border)', display: 'flex', gap: '8px', flexWrap: 'wrap', background: 'var(--bg-secondary)' }}>
        {STATUS_FILTERS.map(f => (
          <button key={f.value} className={`filter-chip ${filterStatus === f.value ? 'active' : ''}`} onClick={() => setFilter('filterStatus', f.value)}>
            {f.label}
          </button>
        ))}
        <button className={`filter-chip ${favouritesOnly ? 'active' : ''}`} onClick={() => setFavouritesOnly(v => !v)}>
          <Star size={11} style={{ verticalAlign: 'middle', marginRight: 3 }} fill={favouritesOnly ? 'currentColor' : 'none'} />
          Favourites
        </button>
        <div style={{ width: 1, background: 'var(--border)', margin: '0 4px' }} />
        {FORMAT_FILTERS.map(f => (
          <button key={f} className={`filter-chip ${filterFormat === f ? 'active' : ''}`} onClick={() => setFilter('filterFormat', f)}>
            {f || 'All formats'}
          </button>
        ))}
        {allTags.length > 0 && (
          <>
            <div style={{ width: 1, background: 'var(--border)', margin: '0 4px' }} />
            <button className={`filter-chip ${activeTag === '' ? 'active' : ''}`} onClick={() => setActiveTag('')}>All tags</button>
            {allTags.map(tag => (
              <button key={tag} className={`filter-chip ${activeTag === tag ? 'active' : ''}`} onClick={() => setActiveTag(tag)}>{tag}</button>
            ))}
          </>
        )}
      </div>

      {/* Content */}
      <div className="page-content">
        {booksLoading ? (
          <div className="empty-state">
            <div className="spinner" style={{ width: 32, height: 32 }} />
            <p>Loading library…</p>
          </div>
        ) : books.length === 0 ? (
          <div className="empty-state">
            <FolderOpen size={64} />
            <h3>Your library is empty</h3>
            <p>Go to <strong>Settings → Library Folders</strong> to add a folder, then hit <strong>Scan</strong> to import your books.</p>
            <button className="btn btn-primary" onClick={() => navigate('/settings')}>
              Open Settings
            </button>
          </div>
        ) : displayedBooks.length === 0 ? (
          <div className="empty-state">
            <Search size={48} />
            <h3>No matches</h3>
            <p>Try clearing your search or filters.</p>
          </div>
        ) : (
          <div className={viewMode === 'grid' ? 'library-grid' : 'library-list'}>
            {displayedBooks.map(book => (
              <BookCard
                key={book.id}
                book={book}
                viewMode={viewMode}
                onOpen={() => navigate(`/read/${book.id}`)}
                onFavourite={() => updateBook(book.id, { is_favourite: book.is_favourite ? 0 : 1 })}
                onDelete={() => {
                  if (confirm(`Remove "${book.title}" from library?`)) deleteBook(book.id)
                }}
              />
            ))}
          </div>
        )}
      </div>
    </>
  )
}
