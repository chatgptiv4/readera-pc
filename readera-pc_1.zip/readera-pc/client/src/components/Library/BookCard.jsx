import React from 'react'
import { Star, Trash2, BookOpen, Tag, FolderInput } from 'lucide-react'
import { useAppStore } from '../../store/appStore'

function parseTags(tags) {
  try { return JSON.parse(tags || '[]') } catch { return [] }
}

const FORMAT_COLORS = {
  PDF: '#e74c3c', EPUB: '#4f8ef7', MOBI: '#9b59b6',
  DOCX: '#2980b9', TXT: '#95a5a6', FB2: '#27ae60',
  DJVU: '#e67e22', CBZ: '#1abc9c', CBR: '#16a085',
}

export default function BookCard({ book, viewMode, onOpen, onFavourite, onDelete }) {
  const percent = book.percent_complete || 0
  const fmtColor = FORMAT_COLORS[book.file_format] || '#666'
  const loadBooks = useAppStore(s => s.loadBooks)
  const libraries = useAppStore(s => s.libraries)
  const moveBookToLibrary = useAppStore(s => s.moveBookToLibrary)
  const tags = parseTags(book.tags)
  const coverUrl = book.cover_path ? `/api/covers/${book.cover_path}` : null

  const handleEditTags = async (e) => {
    e.stopPropagation()
    const input = prompt('Tags (comma-separated):', tags.join(', '))
    if (input === null) return
    const newTags = input.split(',').map(t => t.trim()).filter(Boolean)
    await fetch(`/api/books/${book.id}/tags`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tags: newTags }) })
    loadBooks()
  }

  const handleMoveLibrary = (e) => {
    e.stopPropagation()
    if (libraries.length < 2) { alert('Create another library in Settings first.'); return }
    const options = libraries.map((l, i) => `${i + 1}. ${l.name}`).join('\n')
    const choice = prompt(`Move "${book.title}" to which library?\n\n${options}\n\nEnter a number:`)
    if (!choice) return
    const idx = Number(choice) - 1
    if (libraries[idx]) moveBookToLibrary(book.id, libraries[idx].id)
  }

  const CoverImg = coverUrl ? (
    <img src={coverUrl} alt={book.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
  ) : null

  if (viewMode === 'list') {
    return (
      <div
        className="book-card"
        style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderRadius: 8, marginBottom: 6 }}
        onDoubleClick={onOpen}
      >
        <div style={{ width: 36, height: 48, background: 'var(--bg-tertiary)', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
          {coverUrl ? CoverImg : <span style={{ fontSize: 9, fontWeight: 700, color: fmtColor }}>{book.file_format}</span>}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="book-title">{book.title}</div>
          <div className="book-author">{book.author}</div>
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', flexShrink: 0 }}>
          {percent > 0 ? `${Math.round(percent)}%` : 'Unread'}
        </div>
        <div className="book-actions" style={{ opacity: 1, position: 'static', flexShrink: 0 }}>
          <button className="icon-btn" style={{ background: 'transparent' }} onClick={onFavourite} title="Favourite">
            <Star size={14} fill={book.is_favourite ? '#f5c518' : 'none'} color={book.is_favourite ? '#f5c518' : 'var(--text-muted)'} />
          </button>
          <button className="icon-btn btn-primary" style={{ background: 'var(--accent)' }} onClick={onOpen} title="Open">
            <BookOpen size={14} color="#fff" />
          </button>
          <button className="icon-btn" style={{ background: 'transparent' }} onClick={e => { e.stopPropagation(); onDelete(); }} title="Remove">
            <Trash2 size={14} color="var(--text-muted)" />
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="book-card" onDoubleClick={onOpen}>
      {/* Cover */}
      <div className="book-cover">
        {coverUrl ? CoverImg : (
          <div className="book-cover-placeholder">
            <span className="format-badge" style={{ color: fmtColor, background: `${fmtColor}22` }}>
              {book.file_format}
            </span>
            <span className="cover-title">{book.title}</span>
            {book.author !== 'Unknown' && (
              <span style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center' }}>{book.author}</span>
            )}
          </div>
        )}

        {/* Progress bar */}
        {percent > 0 && (
          <div className="book-progress-bar">
            <div className="book-progress-fill" style={{ width: `${percent}%` }} />
          </div>
        )}

        {/* Quick actions */}
        <div className="book-actions">
          <button className="icon-btn" onClick={e => { e.stopPropagation(); onFavourite(); }} title="Favourite">
            <Star size={12} fill={book.is_favourite ? '#f5c518' : 'none'} color={book.is_favourite ? '#f5c518' : '#fff'} />
          </button>
          <button className="icon-btn" onClick={handleEditTags} title="Edit tags">
            <Tag size={12} color="#fff" />
          </button>
          <button className="icon-btn" onClick={handleMoveLibrary} title="Move to library">
            <FolderInput size={12} color="#fff" />
          </button>
          <button className="icon-btn" onClick={e => { e.stopPropagation(); onDelete(); }} title="Remove">
            <Trash2 size={12} color="#fff" />
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="book-info">
        <div className="book-title" title={book.title}>{book.title}</div>
        <div className="book-author" title={book.author}>{book.author}</div>
        {percent > 0 && (
          <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>{Math.round(percent)}% read</div>
        )}
        {tags.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
            {tags.slice(0, 3).map(t => <span key={t} className="tag-chip">{t}</span>)}
          </div>
        )}
      </div>
    </div>
  )
}
