import React, { useEffect, useState, useRef, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  ArrowLeft, Bookmark, Highlighter, List, Moon,
  ZoomIn, ZoomOut, ChevronLeft, ChevronRight, BookMarked, Settings2,
  Search, Volume2, Pause, Sparkles, ScanText,
} from 'lucide-react'
import { useAppStore } from '../../store/appStore'
import PDFViewer from './PDFViewer'
import EPUBViewer from './EPUBViewer'
import ReaderSidebar from './ReaderSidebar'
import ReaderSettings from './ReaderSettings'
import DictionaryPopup from './DictionaryPopup'
import SearchPanel from './SearchPanel'
import AIPanel from './AIPanel'

const bgMap = { dark: '#121212', light: '#ffffff', sepia: '#f4ede0', console: '#0f1a12' }
const textMap = { dark: '#e8e8e8', light: '#1a1a1a', sepia: '#3d2b1f', console: '#00ff41' }

export default function ReaderPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const {
    currentBook, loadBook, loadBookmarks, loadHighlights,
    bookmarks, highlights, addBookmark, addHighlight, removeBookmark, removeHighlight, updateHighlight,
    saveProgress, fontSize, fontFamily,
    readerSidebarTab, setReaderSidebarTab,
  } = useAppStore()

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [progress, setProgress] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [showSettings, setShowSettings] = useState(false)
  const [zoom, setZoom] = useState(100)
  const [readerTheme, setReaderTheme] = useState('dark')
  const [showSearch, setShowSearch] = useState(false)
  const [showAI, setShowAI] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [dictWord, setDictWord] = useState(null)
  const [dictPos, setDictPos] = useState(null)
  const [ocrLoading, setOcrLoading] = useState(false)
  const [ocrResult, setOcrResult] = useState(null)

  const viewerRef = useRef(null)
  const progressTimer = useRef(null)
  const sessionStart = useRef(Date.now())
  const currentCfiRef = useRef(null)

  const format = currentBook?.file_format?.toLowerCase()
  const fileUrl = `/api/books/${id}/file`

  useEffect(() => {
    const init = async () => {
      setLoading(true)
      try {
        const book = await loadBook(id)
        if (book.current_page) setCurrentPage(book.current_page)
        if (book.percent_complete) setProgress(book.percent_complete)
        await loadBookmarks(id)
        await loadHighlights(id)
      } catch (e) {
        setError('Failed to load book')
      } finally {
        setLoading(false)
      }
    }
    init()

    return () => {
      const elapsed = Math.floor((Date.now() - sessionStart.current) / 1000)
      if (elapsed > 5) useAppStore.getState().saveProgress(id, { time_delta: elapsed })
      window.speechSynthesis?.cancel()
    }
  }, [id])

  const handleProgressUpdate = useCallback((page, total, pct) => {
    setCurrentPage(page)
    if (total) setTotalPages(total)
    setProgress(pct)
    clearTimeout(progressTimer.current)
    progressTimer.current = setTimeout(() => {
      saveProgress(id, { current_page: page, percent_complete: pct, current_cfi: currentCfiRef.current })
    }, 1500)
  }, [id, saveProgress])

  const handleAddBookmark = () => {
    addBookmark(id, { page: currentPage, label: `Page ${currentPage}` })
  }

  const goNext = () => viewerRef.current?.nextPage?.()
  const goPrev = () => viewerRef.current?.prevPage?.()

  // ── Keyboard shortcuts ─────────────────────────────────────────────────
  useEffect(() => {
    const handleKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return
      switch (e.key) {
        case 'ArrowRight': case ' ': case 'PageDown': e.preventDefault(); goNext(); break
        case 'ArrowLeft': case 'PageUp': e.preventDefault(); goPrev(); break
        case '+': case '=': setZoom(z => Math.min(200, z + 10)); break
        case '-': setZoom(z => Math.max(50, z - 10)); break
        case 'b': handleAddBookmark(); break
        case 'f': if (e.ctrlKey || e.metaKey) { e.preventDefault(); setShowSearch(s => !s) } break
        case 'Escape': setShowSearch(false); setShowAI(false); setDictWord(null); break
        default: break
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [currentPage])

  // ── Text-to-speech ─────────────────────────────────────────────────────
  const toggleSpeech = async () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
      return
    }
    let text = ''
    if (format === 'pdf') text = await viewerRef.current?.getCurrentPageText?.()
    else text = viewerRef.current?.getCurrentText?.()
    if (!text) return

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 1
    utterance.onend = () => setIsSpeaking(false)
    window.speechSynthesis.speak(utterance)
    setIsSpeaking(true)
  }

  // ── Dictionary lookup (double-click a word) ─────────────────────────────
  const handleDoubleClick = (e) => {
    const selection = window.getSelection()?.toString()?.trim()
    if (selection && /^[a-zA-Z-]{2,30}$/.test(selection)) {
      setDictWord(selection.toLowerCase())
      setDictPos({ x: e.clientX, y: e.clientY })
    }
  }

  // ── In-book search ───────────────────────────────────────────────────────
  const handleSearch = async (query) => {
    if (format === 'pdf') return await viewerRef.current?.searchDocument?.(query)
    return await viewerRef.current?.search?.(query)
  }
  const handleSearchJump = (result) => {
    if (format === 'pdf' && result.page) viewerRef.current?.goToPage?.(result.page)
    else if (result.cfi) viewerRef.current?.goTo?.(result.cfi)
    setShowSearch(false)
  }

  // ── OCR for scanned PDF pages ────────────────────────────────────────────
  const runOCR = async () => {
    if (format !== 'pdf') return
    setOcrLoading(true)
    setOcrResult(null)
    try {
      const canvas = await viewerRef.current?.renderPageToCanvas?.()
      if (!canvas) return
      const Tesseract = await import('tesseract.js')
      const { data } = await Tesseract.recognize(canvas, 'eng')
      setOcrResult(data.text)
    } catch (e) {
      setOcrResult('OCR failed — this page may not need it, or Tesseract could not load.')
    } finally {
      setOcrLoading(false)
    }
  }

  return (
    <div className="reader-layout" style={{ flexDirection: 'column' }} onDoubleClick={handleDoubleClick}>
      {/* Topbar */}
      <div className="reader-topbar">
        <button className="btn btn-ghost btn-icon" onClick={() => navigate(-1)} title="Back to library">
          <ArrowLeft size={18} />
        </button>

        <button className="btn btn-ghost btn-icon" onClick={goPrev} title="Previous page (←)">
          <ChevronLeft size={18} />
        </button>
        <button className="btn btn-ghost btn-icon" onClick={goNext} title="Next page (→)">
          <ChevronRight size={18} />
        </button>

        <div className="reader-topbar-title">
          {currentBook ? `${currentBook.title}${currentBook.author !== 'Unknown' ? ` · ${currentBook.author}` : ''}` : ''}
        </div>

        {totalPages > 0 && (
          <span style={{ fontSize: 12, color: 'var(--text-muted)', flexShrink: 0 }}>{currentPage} / {totalPages}</span>
        )}

        {format === 'pdf' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setZoom(z => Math.max(50, z - 10))} title="Zoom out (-)"><ZoomOut size={16} /></button>
            <span style={{ fontSize: 12, color: 'var(--text-secondary)', minWidth: 40, textAlign: 'center' }}>{zoom}%</span>
            <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setZoom(z => Math.min(200, z + 10))} title="Zoom in (+)"><ZoomIn size={16} /></button>
          </div>
        )}

        <div style={{ display: 'flex', gap: 4 }}>
          {['dark','light','sepia','console'].map(t => (
            <button key={t} title={t} onClick={() => setReaderTheme(t)}
              style={{ width: 20, height: 20, borderRadius: '50%', background: bgMap[t], border: `2px solid ${readerTheme === t ? 'var(--accent)' : 'var(--border)'}`, cursor: 'pointer' }}
            />
          ))}
        </div>

        <button className="btn btn-ghost btn-icon" onClick={toggleSpeech} title="Read aloud">
          {isSpeaking ? <Pause size={18} color="var(--accent)" /> : <Volume2 size={18} />}
        </button>

        {format === 'pdf' && (
          <button className="btn btn-ghost btn-icon" onClick={runOCR} title="OCR this page (for scanned PDFs)">
            <ScanText size={18} color={ocrLoading ? 'var(--accent)' : 'currentColor'} />
          </button>
        )}

        <button className="btn btn-ghost btn-icon" onClick={() => setShowSearch(s => !s)} title="Search in book (Ctrl+F)">
          <Search size={18} />
        </button>

        <button className="btn btn-ghost btn-icon" onClick={() => setShowAI(s => !s)} title="AI assistant">
          <Sparkles size={18} />
        </button>

        <button className="btn btn-ghost btn-icon" onClick={handleAddBookmark} title="Add bookmark (b)">
          <Bookmark size={18} fill={bookmarks.some(b => b.page === currentPage) ? 'var(--accent)' : 'none'} color={bookmarks.some(b => b.page === currentPage) ? 'var(--accent)' : 'currentColor'} />
        </button>

        <button className={`btn btn-ghost btn-icon ${readerSidebarTab === 'bookmarks' ? 'active' : ''}`} onClick={() => setReaderSidebarTab('bookmarks')} title="Bookmarks">
          <BookMarked size={18} />
        </button>
        <button className={`btn btn-ghost btn-icon ${readerSidebarTab === 'highlights' ? 'active' : ''}`} onClick={() => setReaderSidebarTab('highlights')} title="Highlights">
          <Highlighter size={18} />
        </button>
        <button className="btn btn-ghost btn-icon" onClick={() => setShowSettings(s => !s)} title="Reading settings">
          <Settings2 size={18} />
        </button>
      </div>

      <div className="reader-progress-bar"><div className="reader-progress-fill" style={{ width: `${progress}%` }} /></div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div className="reader-main" style={{ margin: 0, height: '100%', flex: 1, background: bgMap[readerTheme] }}>
          {loading ? (
            <div className="empty-state" style={{ height: '100%' }}>
              <div className="spinner" style={{ width: 32, height: 32 }} />
              <p>Opening book…</p>
            </div>
          ) : error ? (
            <div className="empty-state" style={{ height: '100%' }}>
              <p style={{ color: '#e74c3c' }}>{error}</p>
              <button className="btn btn-secondary" onClick={() => navigate(-1)}>Go back</button>
            </div>
          ) : format === 'pdf' ? (
            <PDFViewer
              ref={viewerRef} url={fileUrl} zoom={zoom} initialPage={currentPage}
              onProgress={handleProgressUpdate} bgColor={bgMap[readerTheme]}
              highlights={highlights}
              onHighlight={(data) => addHighlight(id, data)}
            />
          ) : format === 'txt' ? (
            <PlainTextViewer url={fileUrl} bgColor={bgMap[readerTheme]} textColor={textMap[readerTheme]} fontSize={fontSize} fontFamily={fontFamily} onProgress={handleProgressUpdate} />
          ) : (format === 'epub' || format === 'mobi') ? (
            <EPUBViewer
              ref={viewerRef} url={fileUrl} initialCfi={currentBook?.current_cfi}
              onProgress={handleProgressUpdate}
              onCfiChange={(cfi) => currentCfiRef.current = cfi}
              theme={readerTheme} fontSize={fontSize} fontFamily={fontFamily}
              highlights={highlights}
              onHighlight={(data) => addHighlight(id, data)}
              onToc={() => {}}
            />
          ) : (
            <div className="empty-state" style={{ height: '100%' }}>
              <p>The <strong>{currentBook?.file_format}</strong> format isn't fully supported in the reader yet — that's on the roadmap.</p>
              <p className="text-sm text-muted">For now, try converting it to PDF or EPUB (Calibre works well for this).</p>
              <button className="btn btn-secondary" onClick={() => navigate(-1)}>Go back</button>
            </div>
          )}
        </div>

        {readerSidebarTab && (
          <ReaderSidebar
            tab={readerSidebarTab} bookId={id} bookTitle={currentBook?.title || 'book'}
            bookmarks={bookmarks} highlights={highlights}
            onRemoveBookmark={(bmId) => removeBookmark(bmId, id)}
            onRemoveHighlight={(hlId) => removeHighlight(hlId, id)}
            onEditHighlight={(hlId, data) => updateHighlight(hlId, id, data)}
          />
        )}
      </div>

      {showSettings && <ReaderSettings onClose={() => setShowSettings(false)} />}

      {showSearch && (
        <SearchPanel onSearch={handleSearch} onJump={handleSearchJump} onClose={() => setShowSearch(false)} />
      )}

      {showAI && (
        <AIPanel
          bookTitle={currentBook?.title || 'this book'}
          getContextText={() => format === 'pdf' ? null : viewerRef.current?.getCurrentText?.()}
          onClose={() => setShowAI(false)}
        />
      )}

      {dictWord && (
        <DictionaryPopup word={dictWord} position={dictPos} onClose={() => setDictWord(null)} />
      )}

      {(ocrLoading || ocrResult) && (
        <div className="modal-overlay" onClick={() => { setOcrResult(null) }}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2>OCR result</h2>
            {ocrLoading ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div className="spinner" /> <span>Reading scanned text…</span>
              </div>
            ) : (
              <p style={{ fontSize: 13, lineHeight: 1.6, maxHeight: 300, overflowY: 'auto', whiteSpace: 'pre-wrap' }}>{ocrResult}</p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function PlainTextViewer({ url, bgColor, textColor, fontSize, fontFamily, onProgress }) {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(true)
  const containerRef = useRef(null)

  useEffect(() => {
    fetch(url).then(r => r.text()).then(t => { setText(t); setLoading(false) }).catch(() => { setText('Failed to load file.'); setLoading(false) })
  }, [url])

  const handleScroll = useCallback(() => {
    const el = containerRef.current
    if (!el) return
    const pct = (el.scrollTop / (el.scrollHeight - el.clientHeight)) * 100
    onProgress(1, 1, pct)
  }, [onProgress])

  return (
    <div ref={containerRef} onScroll={handleScroll} style={{ width: '100%', height: '100%', overflowY: 'auto', background: bgColor }}>
      {loading ? (
        <div className="empty-state" style={{ color: textColor }}><div className="spinner" /></div>
      ) : (
        <pre style={{ maxWidth: 720, margin: '0 auto', padding: '48px 32px', color: textColor, fontSize, fontFamily, lineHeight: 1.8, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {text}
        </pre>
      )}
    </div>
  )
}
