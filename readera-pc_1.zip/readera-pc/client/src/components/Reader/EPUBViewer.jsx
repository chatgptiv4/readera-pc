import React, { useEffect, useRef, forwardRef, useImperativeHandle } from 'react'
import Epub from 'epubjs'

const bgMap = { dark: '#121212', light: '#fff', sepia: '#f4ede0', console: '#0f1a12' }
const textMap = { dark: '#e8e8e8', light: '#1a1a1a', sepia: '#3d2b1f', console: '#00ff41' }
const colorMap = { yellow: '#f5c518', green: '#4caf88', pink: '#e06c9f', blue: '#4f8ef7' }

const EPUBViewer = forwardRef(function EPUBViewer(
  { url, initialCfi, onProgress, onCfiChange, theme, fontSize, fontFamily, highlights, onHighlight, onToc },
  ref
) {
  const containerRef = useRef(null)
  const bookRef = useRef(null)
  const renditionRef = useRef(null)

  useEffect(() => {
    if (!containerRef.current) return

    const book = Epub(url)
    bookRef.current = book

    const rendition = book.renderTo(containerRef.current, {
      width: '100%',
      height: '100%',
      flow: 'scrolled-doc',
      manager: 'continuous',
    })
    renditionRef.current = rendition

    rendition.themes.default({
      body: {
        background: bgMap[theme] || '#121212',
        color: textMap[theme] || '#e8e8e8',
        fontSize: `${fontSize || 16}px !important`,
        fontFamily: `${fontFamily || 'Georgia'}, serif !important`,
        lineHeight: '1.8 !important',
        maxWidth: '720px',
        margin: '0 auto',
        padding: '48px 32px',
      }
    })

    rendition.display(initialCfi || undefined)

    book.loaded.navigation.then(nav => {
      onToc?.(nav.toc || [])
    })

    rendition.on('relocated', (location) => {
      const pct = Math.round((location.start.percentage || 0) * 100)
      const page = location.start.displayed?.page || 1
      const total = location.start.displayed?.total || 0
      onProgress(page, total, pct)
      if (onCfiChange) onCfiChange(location.start.cfi)
    })

    rendition.on('selected', (cfiRange, contents) => {
      const selection = contents.window.getSelection()
      const text = selection?.toString()?.trim()
      if (!text || text.length < 2) return
      onHighlight({ cfi_range: cfiRange, selected_text: text, color: 'yellow' })
      rendition.annotations.add('highlight', cfiRange, {}, null, 'hl', {
        fill: '#f5c51880', 'fill-opacity': '0.3', 'mix-blend-mode': 'multiply',
      })
    })

    highlights?.forEach(hl => {
      if (hl.cfi_range) {
        rendition.annotations.add('highlight', hl.cfi_range, {}, null, 'hl', {
          fill: `${colorMap[hl.color] || '#f5c518'}80`, 'fill-opacity': '0.3',
        })
      }
    })

    return () => { try { book.destroy() } catch {} }
  }, [url])

  useEffect(() => {
    if (!renditionRef.current) return
    renditionRef.current.themes.default({
      body: {
        background: bgMap[theme] || '#121212',
        color: textMap[theme] || '#e8e8e8',
        fontSize: `${fontSize || 16}px !important`,
        fontFamily: `${fontFamily || 'Georgia'}, serif !important`,
      }
    })
  }, [theme, fontSize, fontFamily])

  useImperativeHandle(ref, () => ({
    nextPage: () => renditionRef.current?.next(),
    prevPage: () => renditionRef.current?.prev(),
    goTo: (href) => renditionRef.current?.display(href),
    search: async (query) => {
      if (!bookRef.current || !query) return []
      const results = []
      const spineItems = bookRef.current.spine.spineItems
      for (const item of spineItems) {
        await item.load(bookRef.current.load.bind(bookRef.current))
        const matches = item.find(query)
        matches.forEach(m => results.push({ cfi: m.cfi, excerpt: m.excerpt, href: item.href }))
        item.unload()
      }
      return results
    },
    getCurrentText: () => {
      try {
        const contents = renditionRef.current?.getContents?.()
        if (contents && contents[0]) {
          return contents[0].document.body.innerText.slice(0, 6000)
        }
      } catch {}
      return ''
    },
  }))

  return <div ref={containerRef} style={{ width: '100%', height: '100%', background: bgMap[theme] || '#121212' }} />
})

export default EPUBViewer
