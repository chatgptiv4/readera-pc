import React, { useState, useRef, useEffect } from 'react'
import { Sparkles, Send, X, Loader2 } from 'lucide-react'

export default function AIPanel({ bookTitle, getContextText, onClose }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  const send = async (userText) => {
    if (!userText.trim() || loading) return
    const newMessages = [...messages, { role: 'user', content: userText }]
    setMessages(newMessages)
    setInput('')
    setLoading(true)

    try {
      const pageText = getContextText?.() || ''
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: `You are a reading assistant helping with the book "${bookTitle}". Here is the currently visible page/section text for context:\n\n${pageText.slice(0, 4000)}\n\nAnswer questions or summarize based on this context. Be concise.`,
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        }),
      })
      const data = await res.json()
      if (data.error) {
        setMessages(m => [...m, { role: 'assistant', content: `⚠️ ${data.error}` }])
      } else {
        setMessages(m => [...m, { role: 'assistant', content: data.text }])
      }
    } catch (e) {
      setMessages(m => [...m, { role: 'assistant', content: '⚠️ Could not reach AI service.' }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      position: 'fixed', bottom: 20, right: 20, width: 360, height: 480,
      background: 'var(--bg-secondary)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
      display: 'flex', flexDirection: 'column', zIndex: 600, overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 14, borderBottom: '1px solid var(--border)' }}>
        <Sparkles size={16} color="var(--accent)" />
        <strong style={{ fontSize: 14, flex: 1 }}>Ask about this book</strong>
        <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={14} /></button>
      </div>

      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {messages.length === 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <p className="text-sm text-muted">Try asking:</p>
            {['Summarize this page', 'Explain this in simpler terms', 'What are the key takeaways so far?'].map(s => (
              <button key={s} className="btn btn-secondary btn-sm" style={{ justifyContent: 'flex-start' }} onClick={() => send(s)}>
                {s}
              </button>
            ))}
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} style={{
            alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
            maxWidth: '85%',
            background: m.role === 'user' ? 'var(--accent)' : 'var(--bg-tertiary)',
            color: m.role === 'user' ? '#fff' : 'var(--text-primary)',
            padding: '8px 12px', borderRadius: 12, fontSize: 13, lineHeight: 1.5,
            whiteSpace: 'pre-wrap',
          }}>
            {m.content}
          </div>
        ))}
        {loading && (
          <div style={{ alignSelf: 'flex-start', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Loader2 size={14} className="spin" /> <span style={{ fontSize: 13 }}>Thinking…</span>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 8, padding: 12, borderTop: '1px solid var(--border)' }}>
        <input
          placeholder="Ask a question…"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send(input)}
          style={{ flex: 1, background: 'var(--bg-tertiary)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', color: 'var(--text-primary)', fontSize: 13, outline: 'none' }}
        />
        <button className="btn btn-primary btn-icon" onClick={() => send(input)} disabled={loading}>
          <Send size={14} />
        </button>
      </div>
    </div>
  )
}
