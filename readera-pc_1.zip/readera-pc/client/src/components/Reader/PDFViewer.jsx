import React, { useState, useRef, useCallback, forwardRef, useImperativeHandle } from 'react'
import { Document, Page, pdfjs } from 'react-pdf'
import 'react-pdf/dist/Page/AnnotationLayer.css'
import 'react-pdf/dist/Page/TextLayer.css'

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`

const HL_COLORS = { yellow: '#f5c518', green: '#4caf88', pink: '#e06c9f', blue: '#4f8ef7' }

const PDFViewer = forwardRef(function PDFViewer(
  { url, zoom, initialPage, onProgress, bgColor, highlights = [], onHighlight },
  ref
) {
  const [numPages, setNumPages] = useState(null)
  const [currentPage, setCurrentPage] = useState(initialPage || 1)
  const [pdfDoc, setPdfDoc] = useState(null)
  const containerRef = useRef(null)
  const pageRefs = useRef({})
  const scale = zoom / 100

  const onDocumentLoadSuccess = (doc) => {
    setNumPages(doc.numPages)
    setPdfDoc(doc)
    if (initialPage && initialPage > 1) {
      setTimeout(() => scrollToPage(initialPage), 300)
    }
  }

  const scrollToPage = (pageNum) => {
    const el = pageRefs.current[pageNum]
    if (el && containerRef.current) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  const handleScroll = useCallback(() => {
    if (!containerRef.current || !numPages) return
    const container = containerRef.current
    const scrollPct = container.scrollTop / (container.scrollHeight - container.clientHeight)
    const estimatedPage = Math.max(1, Math.min(numPages, Math.round(scrollPct * numPages) || 1))
    const pct = (estimatedPage / numPages) * 100
    setCurrentPage(estimatedPage)
    onProgress(estimatedPage, numPages, Math.min(pct, 100))
  }, [numPages, onProgress])

  // ── Text selection → highlight ────────────────────────────────────────────
  // Rects are stored as percentages of the page wrapper's own bounding box, so
  // they stay correctly positioned at any zoom level without recalculation.
  const handleMouseUp = useCallback(() => {
    if (!onHighlight) return
    const selection = window.getSelection()
    const text = selection?.toString()?.trim()
    if (!text || text.length < 2 || selection.rangeCount === 0) return

    const range = selection.getRangeAt(0)
    let node = range.commonAncestorContainer
    if (node.nodeType === 3) node = node.parentElement
    const pageEl = node?.closest?.('[data-page]')
    if (!pageEl) return

    const pageNum = Number(pageEl.dataset.page)
    const pageRect = pageEl.getBoundingClientRect()
    const clientRects = Array.from(range.getClientRects())
    if (!clientRects.length) return

    const rects = clientRects
      .filter(r => r.width > 0 && r.height > 0)
      .map(r => ({
        left: ((r.left - pageRect.left) / pageRect.width) * 100,
        top: ((r.top - pageRect.top) / pageRect.height) * 100,
        width: (r.width / pageRect.width) * 100,
        height: (r.height / pageRect.height) * 100,
      }))
    if (!rects.length) return

    onHighlight({ page: pageNum, cfi_range: JSON.stringify(rects), selected_text: text, color: 'yellow' })
    selection.removeAllRanges()
  }, [onHighlight])

  useImperativeHandle(ref, () => ({
    nextPage: () => scrollToPage(Math.min(numPages || 1, currentPage + 1)),
    prevPage: () => scrollToPage(Math.max(1, currentPage - 1)),
    goToPage: (n) => scrollToPage(n),
    getCurrentPageText: async () => {
      if (!pdfDoc) return ''
      try {
        const page = await pdfDoc.getPage(currentPage)
        const textContent = await page.getTextContent()
        return textContent.items.map(i => i.str).join(' ')
      } catch { return '' }
    },
    isPageScanned: async () => {
      if (!pdfDoc) return false
      try {
        const page = await pdfDoc.getPage(currentPage)
        const textContent = await page.getTextContent()
        const text = textContent.items.map(i => i.str).join('').trim()
        return text.length < 10
      } catch { return false }
    },
    renderPageToCanvas: async () => {
      if (!pdfDoc) return null
      const page = await pdfDoc.getPage(currentPage)
      const viewport = page.getViewport({ scale: 2 })
      const canvas = document.createElement('canvas')
      canvas.width = viewport.width
      canvas.height = viewport.height
      const ctx = canvas.getContext('2d')
      await page.render({ canvasContext: ctx, viewport }).promise
      return canvas
    },
    searchDocument: async (query) => {
      if (!pdfDoc || !query) return []
      const results = []
      const q = query.toLowerCase()
      for (let p = 1; p <= pdfDoc.numPages; p++) {
        const page = await pdfDoc.getPage(p)
        const textContent = await page.getTextContent()
        const text = textContent.items.map(i => i.str).join(' ')
        if (text.toLowerCase().includes(q)) {
          const idx = text.toLowerCase().indexOf(q)
          results.push({ page: p, excerpt: text.slice(Math.max(0, idx - 40), idx + 60) })
        }
      }
      return results
    },
    currentPage,
    numPages,
  }))

  return (
    <div
      ref={containerRef}
      onScroll={handleScroll}
      onMouseUp={handleMouseUp}
      style={{
        width: '100%', height: '100%',
        overflowY: 'auto', overflowX: 'auto',
        background: bgColor || '#1a1a1a',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        padding: '24px 16px', gap: 12,
      }}
    >
      <Document
        file={url}
        onLoadSuccess={onDocumentLoadSuccess}
        loading={
          <div className="empty-state" style={{ color: '#888', padding: 80 }}>
            <div className="spinner" style={{ width: 32, height: 32 }} />
            <p>Loading PDF…</p>
          </div>
        }
        error={
          <div className="empty-state" style={{ color: '#e74c3c', padding: 80 }}>
            <p>Failed to load PDF. Make sure the file is accessible.</p>
          </div>
        }
      >
        {numPages && Array.from({ length: numPages }, (_, i) => {
          const pageNum = i + 1
          const pageHighlights = highlights.filter(h => h.page === pageNum && h.cfi_range)
          return (
            <div
              key={pageNum}
              ref={el => pageRefs.current[pageNum] = el}
              style={{ marginBottom: 8, position: 'relative' }}
              data-page={pageNum}
            >
              <Page pageNumber={pageNum} scale={scale} renderAnnotationLayer={true} renderTextLayer={true} />
              {pageHighlights.map(h => {
                let rects = []
                try { rects = JSON.parse(h.cfi_range) } catch { return null }
                return rects.map((r, idx) => (
                  <div
                    key={`${h.id}-${idx}`}
                    title={h.note || ''}
                    style={{
                      position: 'absolute',
                      left: `${r.left}%`, top: `${r.top}%`, width: `${r.width}%`, height: `${r.height}%`,
                      background: HL_COLORS[h.color] || HL_COLORS.yellow,
                      opacity: 0.35,
                      pointerEvents: 'none',
                      mixBlendMode: 'multiply',
                    }}
                  />
                ))
              })}
            </div>
          )
        })}
      </Document>
    </div>
  )
})

export default PDFViewer
