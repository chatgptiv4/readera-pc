import React from 'react'
import { X } from 'lucide-react'
import { useAppStore } from '../../store/appStore'

const FONTS = ['Georgia', 'Merriweather', 'Lora', 'Inter', 'Times New Roman', 'Arial', 'JetBrains Mono']

export default function ReaderSettings({ onClose }) {
  const { fontSize, fontFamily, saveSettings } = useAppStore()

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 360 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ marginBottom: 0 }}>Reading settings</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>

        <div style={{ marginBottom: 20 }}>
          <div className="setting-label mb-2">Font size — {fontSize}px</div>
          <input
            type="range" min="12" max="28" value={fontSize}
            onChange={e => saveSettings({ fontSize: Number(e.target.value) })}
            className="w-full"
          />
        </div>

        <div>
          <div className="setting-label mb-2">Font family</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {FONTS.map(f => (
              <button
                key={f}
                className={`btn btn-secondary w-full`}
                style={{
                  justifyContent: 'flex-start',
                  fontFamily: f,
                  borderColor: fontFamily === f ? 'var(--accent)' : 'var(--border)',
                  color: fontFamily === f ? 'var(--accent)' : 'var(--text-primary)',
                }}
                onClick={() => saveSettings({ fontFamily: f })}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
