import React, { useEffect, useState } from 'react'
import { X, BookOpen } from 'lucide-react'

export default function DictionaryPopup({ word, position, onClose }) {
  const [definition, setDefinition] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!word) return
    setLoading(true)
    setError(null)
    fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`)
      .then(r => { if (!r.ok) throw new Error('not found'); return r.json() })
      .then(data => { setDefinition(data[0]); setLoading(false) })
      .catch(() => { setError('No definition found'); setLoading(false) })
  }, [word])

  if (!word) return null

  return (
    <div
      style={{
        position: 'fixed',
        left: Math.min(position?.x || 0, window.innerWidth - 320),
        top: (position?.y || 0) + 20,
        width: 300,
        background: 'var(--bg-secondary)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-md)',
        boxShadow: 'var(--shadow-lg)',
        padding: 16,
        zIndex: 2000,
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <BookOpen size={14} color="var(--accent)" />
          <strong style={{ fontSize: 15, textTransform: 'capitalize' }}>{word}</strong>
        </div>
        <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={14} /></button>
      </div>

      {loading && <div className="spinner" style={{ width: 16, height: 16 }} />}
      {error && <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>{error}</p>}

      {definition && (
        <div style={{ maxHeight: 200, overflowY: 'auto' }}>
          {definition.phonetic && (
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>{definition.phonetic}</p>
          )}
          {definition.meanings?.slice(0, 2).map((m, i) => (
            <div key={i} style={{ marginBottom: 10 }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--accent)', textTransform: 'uppercase' }}>
                {m.partOfSpeech}
              </span>
              <p style={{ fontSize: 13, lineHeight: 1.5, marginTop: 2 }}>
                {m.definitions?.[0]?.definition}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
