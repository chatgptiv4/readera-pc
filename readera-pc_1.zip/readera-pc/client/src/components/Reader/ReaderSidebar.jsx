import React from 'react'
import { Bookmark, Highlighter, List, Trash2, Download, StickyNote } from 'lucide-react'

const HL_COLORS = ['yellow', 'green', 'pink', 'blue']
const HL_COLOR_HEX = { yellow: '#f5c518', green: '#4caf88', pink: '#e06c9f', blue: '#4f8ef7' }

function exportNotes(bookTitle, bookmarks, highlights) {
  let md = `# Notes — ${bookTitle}\n\n`
  if (bookmarks.length) {
    md += `## Bookmarks\n\n`
    bookmarks.forEach(b => { md += `- ${b.label} _(${new Date(b.created_at).toLocaleDateString()})_\n` })
    md += `\n`
  }
  if (highlights.length) {
    md += `## Highlights\n\n`
    highlights.forEach(h => {
      md += `> ${h.selected_text}\n`
      if (h.note) md += `\n**Note:** ${h.note}\n`
      md += `\n_${new Date(h.created_at).toLocaleDateString()}_\n\n---\n\n`
    })
  }
  const blob = new Blob([md], { type: 'text/markdown' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${bookTitle.replace(/[^a-z0-9]/gi, '_')}-notes.md`
  a.click()
  URL.revokeObjectURL(url)
}

export default function ReaderSidebar({ tab, bookTitle, bookmarks, highlights, onRemoveBookmark, onRemoveHighlight, onEditHighlight }) {
  return (
    <div className="reader-sidebar">
      <div className="reader-sidebar-tabs">
        <div className={`reader-sidebar-tab ${tab === 'toc' ? 'active' : ''}`}>
          <List size={14} style={{ margin: '0 auto' }} />
        </div>
        <div className={`reader-sidebar-tab ${tab === 'bookmarks' ? 'active' : ''}`}>
          <Bookmark size={14} style={{ margin: '0 auto' }} />
        </div>
        <div className={`reader-sidebar-tab ${tab === 'highlights' ? 'active' : ''}`}>
          <Highlighter size={14} style={{ margin: '0 auto' }} />
        </div>
      </div>

      <div className="reader-sidebar-content">
        {tab === 'toc' && (
          <div>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', padding: '8px 0' }}>
              Table of contents is available for EPUB books. Navigate chapters from within the reader.
            </p>
          </div>
        )}

        {tab === 'bookmarks' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h4 style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Bookmarks ({bookmarks.length})
              </h4>
              {(bookmarks.length > 0 || highlights.length > 0) && (
                <button className="btn btn-ghost btn-icon btn-sm" title="Export notes" onClick={() => exportNotes(bookTitle, bookmarks, highlights)}>
                  <Download size={13} />
                </button>
              )}
            </div>
            {bookmarks.length === 0 ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No bookmarks yet. Tap the bookmark icon to save your place.</p>
            ) : (
              bookmarks.map(bm => (
                <div key={bm.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <Bookmark size={14} color="var(--accent)" fill="var(--accent)" />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{bm.label}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{new Date(bm.created_at).toLocaleDateString()}</div>
                  </div>
                  <button className="btn btn-ghost btn-icon btn-sm" onClick={() => onRemoveBookmark(bm.id)}>
                    <Trash2 size={12} />
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {tab === 'highlights' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <h4 style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Highlights ({highlights.length})
              </h4>
              {(bookmarks.length > 0 || highlights.length > 0) && (
                <button className="btn btn-ghost btn-icon btn-sm" title="Export notes" onClick={() => exportNotes(bookTitle, bookmarks, highlights)}>
                  <Download size={13} />
                </button>
              )}
            </div>
            {highlights.length === 0 ? (
              <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No highlights yet. Select text in the reader to highlight it.</p>
            ) : (
              highlights.map(hl => {
                const cycleColor = () => {
                  const next = HL_COLORS[(HL_COLORS.indexOf(hl.color) + 1) % HL_COLORS.length]
                  onEditHighlight(hl.id, { color: next })
                }
                const editNote = () => {
                  const note = prompt('Note for this highlight:', hl.note || '')
                  if (note !== null) onEditHighlight(hl.id, { note })
                }
                return (
                  <div key={hl.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
                      <button
                        onClick={cycleColor} title="Click to change color"
                        style={{ width: 3, minWidth: 3, height: 'auto', alignSelf: 'stretch', minHeight: 40, background: HL_COLOR_HEX[hl.color] || HL_COLOR_HEX.yellow, borderRadius: 2, flexShrink: 0, cursor: 'pointer', border: 'none', padding: 0 }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 13, lineHeight: 1.5, fontStyle: 'italic', color: 'var(--text-primary)', marginBottom: 4 }}>
                          "{hl.selected_text}"
                        </p>
                        {hl.note && <p style={{ fontSize: 12, color: 'var(--text-secondary)', background: 'var(--bg-tertiary)', borderRadius: 6, padding: '6px 8px', marginBottom: 4 }}>{hl.note}</p>}
                        <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                          {new Date(hl.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                        <button className="btn btn-ghost btn-icon btn-sm" title="Add/edit note" onClick={editNote}>
                          <StickyNote size={12} />
                        </button>
                        <button className="btn btn-ghost btn-icon btn-sm" title="Remove" onClick={() => onRemoveHighlight(hl.id)}>
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        )}
      </div>
    </div>
  )
}
