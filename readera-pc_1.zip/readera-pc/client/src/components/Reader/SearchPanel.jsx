import React, { useState } from 'react'
import { Search, X } from 'lucide-react'

export default function SearchPanel({ onSearch, onJump, onClose }) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)

  const runSearch = async () => {
    if (!query.trim()) return
    setLoading(true)
    const res = await onSearch(query.trim())
    setResults(res || [])
    setLoading(false)
  }

  return (
    <div style={{
      position: 'fixed', top: 56, right: 20, width: 320, maxHeight: '70vh',
      background: 'var(--bg-secondary)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-lg)',
      display: 'flex', flexDirection: 'column', zIndex: 500, overflow: 'hidden',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: 12, borderBottom: '1px solid var(--border)' }}>
        <Search size={16} color="var(--text-muted)" />
        <input
          autoFocus
          placeholder="Search in this book…"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && runSearch()}
          style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--text-primary)', fontSize: 14 }}
        />
        <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={14} /></button>
      </div>

      <div style={{ overflowY: 'auto', flex: 1, padding: results.length ? 8 : 0 }}>
        {loading ? (
          <div style={{ padding: 24, textAlign: 'center' }}><div className="spinner" /></div>
        ) : results.length === 0 && query ? (
          <p style={{ padding: 16, fontSize: 13, color: 'var(--text-muted)' }}>Press Enter to search, or no matches found.</p>
        ) : (
          results.map((r, i) => (
            <div
              key={i}
              onClick={() => onJump(r)}
              style={{ padding: '10px 12px', borderRadius: 6, cursor: 'pointer', fontSize: 13 }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              {r.page && <div style={{ fontSize: 11, color: 'var(--accent)', marginBottom: 2 }}>Page {r.page}</div>}
              <div style={{ color: 'var(--text-secondary)', lineHeight: 1.4 }}>…{r.excerpt}…</div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
