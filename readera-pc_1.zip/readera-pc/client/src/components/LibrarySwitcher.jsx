import React, { useEffect, useState } from 'react'
import { Library, ChevronDown, Plus } from 'lucide-react'
import { useAppStore } from '../store/appStore'

export default function LibrarySwitcher() {
  const { libraries, loadLibraries, activeLibraryId, setActiveLibrary, createLibrary } = useAppStore()
  const [open, setOpen] = useState(false)

  useEffect(() => { loadLibraries() }, [])

  const activeName = activeLibraryId
    ? libraries.find(l => l.id === activeLibraryId)?.name || 'Library'
    : 'All Libraries'

  const handleCreate = async () => {
    const name = prompt('New library name:')
    if (!name?.trim()) return
    const lib = await createLibrary(name.trim())
    setActiveLibrary(lib.id)
    setOpen(false)
  }

  return (
    <div style={{ position: 'relative' }}>
      <button className="btn btn-secondary btn-sm" onClick={() => setOpen(o => !o)}>
        <Library size={14} /> {activeName} <ChevronDown size={13} />
      </button>

      {open && (
        <>
          <div style={{ position: 'fixed', inset: 0, zIndex: 400 }} onClick={() => setOpen(false)} />
          <div style={{
            position: 'absolute', top: '110%', left: 0, minWidth: 180, zIndex: 401,
            background: 'var(--bg-secondary)', border: '1px solid var(--border)',
            borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-md)', padding: 6,
          }}>
            <div
              className="nav-item" style={{ borderRadius: 6, cursor: 'pointer' }}
              onClick={() => { setActiveLibrary(null); setOpen(false) }}
            >
              All Libraries
            </div>
            {libraries.map(lib => (
              <div
                key={lib.id}
                className="nav-item" style={{ borderRadius: 6, cursor: 'pointer', color: activeLibraryId === lib.id ? 'var(--accent)' : undefined }}
                onClick={() => { setActiveLibrary(lib.id); setOpen(false) }}
              >
                {lib.name}
              </div>
            ))}
            <div className="divider" style={{ margin: '4px 0' }} />
            <div className="nav-item" style={{ borderRadius: 6, cursor: 'pointer' }} onClick={handleCreate}>
              <Plus size={14} /> New library
            </div>
          </div>
        </>
      )}
    </div>
  )
}
