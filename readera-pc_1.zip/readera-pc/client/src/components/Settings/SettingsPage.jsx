import React, { useEffect, useState } from 'react'
import { FolderPlus, Trash2, Moon, Sun, Coffee, Library, Plus, Key, Info } from 'lucide-react'
import { useAppStore } from '../../store/appStore'

export default function SettingsPage() {
  const {
    theme, dailyGoalPages, watchFolders, saveSettings, loadBooks,
    libraries, loadLibraries, createLibrary,
  } = useAppStore()
  const [browsePath, setBrowsePath] = useState('')
  const [browseEntries, setBrowseEntries] = useState(null)
  const [browseTargetLibrary, setBrowseTargetLibrary] = useState(1)
  const [importTargetLibrary, setImportTargetLibrary] = useState(1)
  const [newLibName, setNewLibName] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [apiKeySaved, setApiKeySaved] = useState(false)
  const [importing, setImporting] = useState(false)

  useEffect(() => {
    loadLibraries()
    fetch('/api/settings').then(r => r.json()).then(s => setApiKey(s.anthropic_api_key ? '••••••••' + (s.anthropic_api_key.slice(-4)) : ''))
  }, [])

  // Normalises a watch_folders entry to { path, libraryId } — handles both
  // the legacy plain-string format and the current object format.
  const normalise = (f) => typeof f === 'string' ? { path: f, libraryId: 1 } : f

  const browseTo = async (path) => {
    const res = await fetch(`/api/browse?path=${encodeURIComponent(path || '')}`)
    const data = await res.json()
    if (data.error) return
    setBrowsePath(data.current)
    setBrowseEntries(data)
  }

  const addFolder = async (folderPath) => {
    const updated = [...watchFolders.map(normalise).filter(f => f.path !== folderPath), { path: folderPath, libraryId: Number(browseTargetLibrary) }]
    await saveSettings({ watchFolders: updated })
    setBrowseEntries(null)
    loadBooks()
  }

  const removeFolder = async (folderPath) => {
    await saveSettings({ watchFolders: watchFolders.map(normalise).filter(f => f.path !== folderPath) })
  }

  const addLibrary = async () => {
    if (!newLibName.trim()) return
    await createLibrary(newLibName.trim())
    setNewLibName('')
  }

  const saveApiKey = async () => {
    if (!apiKey || apiKey.startsWith('••')) return
    await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ anthropic_api_key: apiKey }) })
    setApiKeySaved(true)
    setTimeout(() => setApiKeySaved(false), 2000)
  }

  const handleImport = async (e) => {
    const files = e.target.files
    if (!files.length) return
    setImporting(true)
    const formData = new FormData()
    for (const f of files) formData.append('books', f)
    formData.append('library_id', importTargetLibrary)
    try {
      await fetch('/api/import', { method: 'POST', body: formData })
      await loadBooks()
    } finally {
      setImporting(false)
      e.target.value = ''
    }
  }

  return (
    <div className="page-content" style={{ maxWidth: 640, margin: '0 auto', width: '100%' }}>
      <div className="page-header">
        <h1>Settings</h1>
        <p>Configure your library, appearance, and AI features</p>
      </div>

      {/* Import books */}
      <div className="settings-section">
        <h3>Import books</h3>
        <p className="text-sm text-secondary mb-4">Upload PDF or EPUB files directly, or add a folder below to auto-import everything inside it.</p>

        {libraries.length > 1 && (
          <div className="setting-row" style={{ border: 'none', paddingTop: 0 }}>
            <div className="setting-label">Add to library</div>
            <select className="select-input" value={importTargetLibrary} onChange={e => setImportTargetLibrary(e.target.value)}>
              {libraries.map(lib => <option key={lib.id} value={lib.id}>{lib.name}</option>)}
            </select>
          </div>
        )}

        <label className="btn btn-primary mt-2" style={{ cursor: 'pointer' }}>
          {importing ? <><div className="spinner" style={{ width: 14, height: 14 }} /> Importing…</> : <>Choose files to import</>}
          <input type="file" multiple accept=".pdf,.epub,.mobi,.txt,.docx" style={{ display: 'none' }} onChange={handleImport} disabled={importing} />
        </label>
      </div>

      {/* Library folders */}
      <div className="settings-section">
        <h3>Library folders</h3>
        <p className="text-sm text-secondary mb-4">Folders are watched automatically — new files added here appear in your library.</p>

        {watchFolders.length > 0 ? (
          watchFolders.map(normalise).map(f => (
            <div className="folder-tag" key={f.path}>
              <span>{f.path}</span>
              {libraries.length > 1 && (
                <span className="tag-chip" style={{ flexShrink: 0 }}>{libraries.find(l => l.id === f.libraryId)?.name || 'My Library'}</span>
              )}
              <button className="btn btn-ghost btn-icon btn-sm" onClick={() => removeFolder(f.path)}><Trash2 size={13} /></button>
            </div>
          ))
        ) : (
          <p className="text-sm text-muted mb-2">No folders added yet.</p>
        )}

        {libraries.length > 1 && (
          <div className="setting-row" style={{ border: 'none' }}>
            <div className="setting-label">New folders go to</div>
            <select className="select-input" value={browseTargetLibrary} onChange={e => setBrowseTargetLibrary(e.target.value)}>
              {libraries.map(lib => <option key={lib.id} value={lib.id}>{lib.name}</option>)}
            </select>
          </div>
        )}

        <button className="btn btn-secondary btn-sm mt-4" onClick={() => browseTo('')}>
          <FolderPlus size={14} /> Browse for folder
        </button>

        {browseEntries && (
          <div style={{ marginTop: 12, border: '1px solid var(--border)', borderRadius: 8, padding: 12, maxHeight: 240, overflowY: 'auto' }}>
            <div className="flex items-center gap-2 mb-2">
              <button className="btn btn-ghost btn-sm" onClick={() => browseTo(browseEntries.parent)}>← Up</button>
              <span className="text-xs text-muted truncate">{browsePath}</span>
            </div>
            <button className="btn btn-primary btn-sm w-full mb-2" onClick={() => addFolder(browsePath)}>
              Add this folder ({browsePath.split('/').pop() || browsePath})
            </button>
            {browseEntries.folders.map(folder => (
              <div key={folder.path} className="nav-item" style={{ cursor: 'pointer', borderRadius: 6 }} onClick={() => browseTo(folder.path)}>
                📁 {folder.name}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Appearance */}
      <div className="settings-section">
        <h3>Appearance</h3>
        <div className="setting-row">
          <div>
            <div className="setting-label">Theme</div>
            <div className="setting-desc">Applies to the whole app</div>
          </div>
          <div className="theme-picker">
            <button className={`theme-option dark ${theme === 'dark' ? 'active' : ''}`} onClick={() => saveSettings({ theme: 'dark' })} title="Dark"><Moon size={14} color="#888" /></button>
            <button className={`theme-option light ${theme === 'light' ? 'active' : ''}`} onClick={() => saveSettings({ theme: 'light' })} title="Light"><Sun size={14} color="#888" /></button>
            <button className={`theme-option sepia ${theme === 'sepia' ? 'active' : ''}`} onClick={() => saveSettings({ theme: 'sepia' })} title="Sepia"><Coffee size={14} color="#8b5e3c" /></button>
          </div>
        </div>
      </div>

      {/* Reading goal */}
      <div className="settings-section">
        <h3>Reading goal</h3>
        <div className="setting-row">
          <div>
            <div className="setting-label">Daily page goal</div>
            <div className="setting-desc">Used for streaks and motivation stats</div>
          </div>
          <input
            type="number" min="1" max="500" value={dailyGoalPages}
            onChange={e => saveSettings({ dailyGoalPages: Number(e.target.value) })}
            className="select-input" style={{ width: 80, textAlign: 'center' }}
          />
        </div>
      </div>

      {/* Multiple libraries */}
      <div className="settings-section">
        <h3>Libraries</h3>
        <p className="text-sm text-secondary mb-4">Separate collections — e.g. "Fiction" and "Technical Books". Use the switcher at the top of your Library page to jump between them.</p>
        {libraries.map(lib => (
          <div key={lib.id} className="folder-tag">
            <Library size={13} /> <span>{lib.name}</span>
          </div>
        ))}
        <div className="flex gap-2 mt-2">
          <input className="select-input flex-1" placeholder="New library name" value={newLibName} onChange={e => setNewLibName(e.target.value)} />
          <button className="btn btn-secondary btn-sm" onClick={addLibrary}><Plus size={14} /> Add</button>
        </div>
      </div>

      {/* AI features */}
      <div className="settings-section">
        <h3>AI features</h3>
        <p className="text-sm text-secondary mb-4">
          Powers AI summaries and "chat with book". Uses your own Anthropic API key — stored locally, never sent anywhere except api.anthropic.com.
        </p>
        <div className="flex gap-2">
          <input
            type="password" className="select-input flex-1" placeholder="sk-ant-…"
            value={apiKey} onChange={e => setApiKey(e.target.value)}
          />
          <button className="btn btn-primary btn-sm" onClick={saveApiKey}>
            <Key size={14} /> {apiKeySaved ? 'Saved!' : 'Save'}
          </button>
        </div>
        <p className="text-xs text-muted mt-2">
          <Info size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} />
          Get a key at console.anthropic.com — pay-as-you-go, typically fractions of a cent per summary.
        </p>
      </div>
    </div>
  )
}
