import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BookOpen, Flame, Clock, ArrowRight } from 'lucide-react'
import { useAppStore } from '../../store/appStore'
import BookCard from '../Library/BookCard'

export default function HomePage() {
  const navigate = useNavigate()
  const { books, loadBooks, stats, loadStats, dailyGoalPages, updateBook, deleteBook } = useAppStore()
  const [greeting, setGreeting] = useState('')

  useEffect(() => {
    loadBooks()
    loadStats()
    const hour = new Date().getHours()
    setGreeting(hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening')
  }, [])

  const continueReading = books.filter(b => b.reading_status === 'reading').sort((a, b) => new Date(b.last_read || 0) - new Date(a.last_read || 0))
  const recentlyAdded = [...books].sort((a, b) => new Date(b.date_added) - new Date(a.date_added)).slice(0, 6)
  const favourites = books.filter(b => b.is_favourite)

  return (
    <div className="page-content">
      <div className="page-header">
        <h1>{greeting}</h1>
        <p>{books.length === 0 ? 'Your library is empty — add some books to get started.' : `You have ${books.length} book${books.length !== 1 ? 's' : ''} in your library.`}</p>
      </div>

      {/* Continue reading */}
      {continueReading.length > 0 && (
        <section style={{ marginBottom: 32 }}>
          <div className="flex items-center gap-2 mb-4">
            <BookOpen size={16} color="var(--accent)" />
            <h2 style={{ fontSize: 16, fontWeight: 600 }}>Continue reading</h2>
          </div>
          <div className="library-grid">
            {continueReading.slice(0, 6).map(book => (
              <BookCard key={book.id} book={book} viewMode="grid"
                onOpen={() => navigate(`/read/${book.id}`)}
                onFavourite={() => updateBook(book.id, { is_favourite: book.is_favourite ? 0 : 1 })}
                onDelete={() => confirm(`Remove "${book.title}"?`) && deleteBook(book.id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Daily goal card */}
      {stats && (
        <section className="stat-card" style={{ marginBottom: 32, display: 'flex', alignItems: 'center', gap: 16 }}>
          <Flame size={32} color="#f5871f" />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 15 }}>Daily goal: {dailyGoalPages} pages</div>
            <div className="text-sm text-secondary">Keep your streak alive — open a book to log today's reading.</div>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/stats')}>
            View stats <ArrowRight size={14} />
          </button>
        </section>
      )}

      {/* Favourites */}
      {favourites.length > 0 && (
        <section style={{ marginBottom: 32 }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 16 }}>⭐ Favourites</h2>
          <div className="library-grid">
            {favourites.slice(0, 6).map(book => (
              <BookCard key={book.id} book={book} viewMode="grid"
                onOpen={() => navigate(`/read/${book.id}`)}
                onFavourite={() => updateBook(book.id, { is_favourite: 0 })}
                onDelete={() => confirm(`Remove "${book.title}"?`) && deleteBook(book.id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Recently added */}
      {recentlyAdded.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Clock size={16} color="var(--text-secondary)" />
            <h2 style={{ fontSize: 16, fontWeight: 600 }}>Recently added</h2>
          </div>
          <div className="library-grid">
            {recentlyAdded.map(book => (
              <BookCard key={book.id} book={book} viewMode="grid"
                onOpen={() => navigate(`/read/${book.id}`)}
                onFavourite={() => updateBook(book.id, { is_favourite: book.is_favourite ? 0 : 1 })}
                onDelete={() => confirm(`Remove "${book.title}"?`) && deleteBook(book.id)}
              />
            ))}
          </div>
        </section>
      )}

      {books.length === 0 && (
        <div className="empty-state">
          <BookOpen size={64} />
          <h3>Nothing here yet</h3>
          <p>Go to Settings to import books or add a watch folder.</p>
          <button className="btn btn-primary" onClick={() => navigate('/settings')}>Open Settings</button>
        </div>
      )}
    </div>
  )
}
