import React from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { BookOpen, BarChart2, Settings, ChevronLeft, ChevronRight, Library, Home } from 'lucide-react'
import { useAppStore } from '../store/appStore'

const NAV = [
  { to: '/', icon: Home, label: 'Home', end: true },
  { to: '/library', icon: Library, label: 'Library' },
  { to: '/stats', icon: BarChart2, label: 'Stats' },
  { to: '/settings', icon: Settings, label: 'Settings' },
]

export default function Layout() {
  const { sidebarOpen, toggleSidebar } = useAppStore()

  return (
    <div className="app-layout">
      <aside className={`sidebar ${sidebarOpen ? '' : 'collapsed'}`}>
        {/* Logo */}
        <div className="sidebar-logo">
          <div className="sidebar-logo-icon">
            <BookOpen size={16} color="#fff" />
          </div>
          {sidebarOpen && <span className="sidebar-logo-text">ReadEra PC</span>}
        </div>

        {/* Nav */}
        <nav className="sidebar-nav">
          {NAV.map(({ to, icon: Icon, label, end }) => (
            <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
              <Icon size={18} />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Collapse toggle */}
        <div className="sidebar-footer">
          <button className="nav-item w-full" onClick={toggleSidebar}>
            {sidebarOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
            {sidebarOpen && <span style={{ fontSize: 13 }}>Collapse</span>}
          </button>
        </div>
      </aside>

      <main className="main-content">
        <Outlet />
      </main>
    </div>
  )
}
