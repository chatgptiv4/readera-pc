import React, { useEffect } from 'react'
import { BookOpen, CheckCircle, Clock, TrendingUp } from 'lucide-react'
import { useAppStore } from '../../store/appStore'

function formatTime(seconds) {
  const hrs = Math.floor(seconds / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  if (hrs > 0) return `${hrs}h ${mins}m`
  return `${mins}m`
}

export default function StatsPage() {
  const { stats, loadStats, dailyGoalPages } = useAppStore()

  useEffect(() => { loadStats() }, [])

  if (!stats) {
    return <div className="page-content"><div className="spinner" /></div>
  }

  return (
    <div className="page-content">
      <div className="page-header">
        <h1>Reading stats</h1>
        <p>Your reading habits at a glance</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{stats.total}</div>
          <div className="stat-label"><BookOpen size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />Total books</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.finished}</div>
          <div className="stat-label"><CheckCircle size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />Finished</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.reading}</div>
          <div className="stat-label"><TrendingUp size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />Currently reading</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{formatTime(stats.totalReadTime)}</div>
          <div className="stat-label"><Clock size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />Total time read</div>
        </div>
      </div>

      <div className="settings-section">
        <h3>Recently active</h3>
        {stats.recentBooks?.length === 0 ? (
          <p className="text-sm text-muted">No reading activity yet. Open a book to get started.</p>
        ) : (
          stats.recentBooks?.map((b, i) => (
            <div key={i} className="setting-row">
              <div>
                <div className="setting-label">{b.title}</div>
                <div className="setting-desc">{b.author}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent)' }}>{Math.round(b.percent_complete)}%</div>
                <div className="text-xs text-muted">{new Date(b.last_read).toLocaleDateString()}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
