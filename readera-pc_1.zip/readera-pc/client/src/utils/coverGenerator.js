import { pdfjs } from 'react-pdf'
import Epub from 'epubjs'

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`

const COVER_WIDTH = 300

async function uploadCover(bookId, blob) {
  const formData = new FormData()
  formData.append('cover', blob, 'cover.jpg')
  const res = await fetch(`/api/books/${bookId}/cover`, { method: 'POST', body: formData })
  return res.ok
}

async function canvasToBlob(canvas) {
  return new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.85))
}

async function generatePdfCover(bookId, fileUrl) {
  const doc = await pdfjs.getDocument(fileUrl).promise
  const page = await doc.getPage(1)
  const baseViewport = page.getViewport({ scale: 1 })
  const scale = COVER_WIDTH / baseViewport.width
  const viewport = page.getViewport({ scale })

  const canvas = document.createElement('canvas')
  canvas.width = viewport.width
  canvas.height = viewport.height
  const ctx = canvas.getContext('2d')
  await page.render({ canvasContext: ctx, viewport }).promise

  const blob = await canvasToBlob(canvas)
  if (blob) return uploadCover(bookId, blob)
  return false
}

async function generateEpubCover(bookId, fileUrl) {
  const book = Epub(fileUrl)
  await book.ready
  const coverUrl = await book.coverUrl()
  if (!coverUrl) { book.destroy(); return false }

  const img = new Image()
  img.crossOrigin = 'anonymous'
  const loaded = new Promise((resolve, reject) => {
    img.onload = resolve
    img.onerror = reject
  })
  img.src = coverUrl
  await loaded

  const canvas = document.createElement('canvas')
  const scale = COVER_WIDTH / img.width
  canvas.width = COVER_WIDTH
  canvas.height = img.height * scale
  const ctx = canvas.getContext('2d')
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

  const blob = await canvasToBlob(canvas)
  book.destroy()
  if (blob) return uploadCover(bookId, blob)
  return false
}

// Generates and uploads a real cover thumbnail for a book. Silently no-ops on failure —
// the UI just keeps showing the placeholder cover if this doesn't work out.
export async function generateCoverIfMissing(book) {
  if (book.cover_path) return false
  const fileUrl = `/api/books/${book.id}/file`
  try {
    if (book.file_format === 'PDF') return await generatePdfCover(book.id, fileUrl)
    if (book.file_format === 'EPUB') return await generateEpubCover(book.id, fileUrl)
  } catch (e) {
    console.warn(`Cover generation failed for "${book.title}":`, e.message)
  }
  return false
}

// Runs cover generation for a batch of books, one at a time, so we don't hammer
// the browser or the server. Calls onEachDone after every successful cover.
export async function generateMissingCovers(books, onEachDone) {
  const needCovers = books.filter(b => !b.cover_path && (b.file_format === 'PDF' || b.file_format === 'EPUB'))
  for (const book of needCovers) {
    const ok = await generateCoverIfMissing(book)
    if (ok && onEachDone) onEachDone(book)
  }
}
