import { create } from 'zustand'

const API = 'http://localhost:3001/api'

export const useAppStore = create((set, get) => ({
  // ── Settings ──────────────────────────────────────────────────────────────
  theme: 'dark',
  fontSize: 16,
  fontFamily: 'Georgia',
  dailyGoalPages: 20,
  watchFolders: [],

  loadSettings: async () => {
    try {
      const res = await fetch(`${API}/settings`)
      const s = await res.json()
      set({
        theme: s.theme || 'dark',
        fontSize: Number(s.font_size) || 16,
        fontFamily: s.font_family || 'Georgia',
        dailyGoalPages: Number(s.daily_goal_pages) || 20,
        watchFolders: s.watch_folders || [],
      })
    } catch (e) {
      console.error('Failed to load settings:', e)
    }
  },

  saveSettings: async (updates) => {
    const keyMap = {
      theme: 'theme',
      fontSize: 'font_size',
      fontFamily: 'font_family',
      dailyGoalPages: 'daily_goal_pages',
      watchFolders: 'watch_folders',
    }
    const payload = {}
    for (const [k, v] of Object.entries(updates)) {
      if (keyMap[k]) payload[keyMap[k]] = v
    }
    await fetch(`${API}/settings`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    set(updates)
  },

  // ── Libraries ─────────────────────────────────────────────────────────────
  libraries: [],
  activeLibraryId: Number(localStorage.getItem('readera_active_library')) || null, // null = All libraries

  loadLibraries: async () => {
    const res = await fetch(`${API}/libraries`)
    const libraries = await res.json()
    set({ libraries })
  },

  setActiveLibrary: (id) => {
    if (id) localStorage.setItem('readera_active_library', id)
    else localStorage.removeItem('readera_active_library')
    set({ activeLibraryId: id })
    get().loadBooks()
  },

  createLibrary: async (name) => {
    const res = await fetch(`${API}/libraries`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    const lib = await res.json()
    set(s => ({ libraries: [...s.libraries, lib] }))
    return lib
  },

  moveBookToLibrary: async (bookId, libraryId) => {
    await fetch(`${API}/books/${bookId}/library`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ library_id: libraryId }) })
    get().loadBooks()
  },

  // ── Books ─────────────────────────────────────────────────────────────────
  books: [],
  booksLoading: false,
  searchQuery: '',
  filterStatus: '',
  filterFormat: '',
  sortBy: 'date_added',

  loadBooks: async () => {
    set({ booksLoading: true })
    try {
      const { searchQuery, filterStatus, filterFormat, sortBy, activeLibraryId } = get()
      const params = new URLSearchParams()
      if (searchQuery) params.set('search', searchQuery)
      if (filterStatus) params.set('status', filterStatus)
      if (filterFormat) params.set('format', filterFormat)
      if (sortBy) params.set('sort', sortBy)
      if (activeLibraryId) params.set('library_id', activeLibraryId)
      const res = await fetch(`${API}/books?${params}`)
      const books = await res.json()
      set({ books, booksLoading: false })
    } catch (e) {
      console.error('Failed to load books:', e)
      set({ booksLoading: false })
    }
  },

  setSearch: (q) => { set({ searchQuery: q }); get().loadBooks() },
  setFilter: (key, val) => { set({ [key]: val }); get().loadBooks() },
  setSortBy: (sort) => { set({ sortBy: sort }); get().loadBooks() },

  updateBook: async (id, data) => {
    await fetch(`${API}/books/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
    get().loadBooks()
  },

  deleteBook: async (id) => {
    await fetch(`${API}/books/${id}`, { method: 'DELETE' })
    get().loadBooks()
  },

  // ── Current book / reader ─────────────────────────────────────────────────
  currentBook: null,
  bookmarks: [],
  highlights: [],

  loadBook: async (id) => {
    const res = await fetch(`${API}/books/${id}`)
    const book = await res.json()
    set({ currentBook: book })
    return book
  },

  loadBookmarks: async (bookId) => {
    const res = await fetch(`${API}/books/${bookId}/bookmarks`)
    const bookmarks = await res.json()
    set({ bookmarks })
  },

  addBookmark: async (bookId, data) => {
    await fetch(`${API}/books/${bookId}/bookmarks`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
    get().loadBookmarks(bookId)
  },

  removeBookmark: async (bookmarkId, bookId) => {
    await fetch(`${API}/bookmarks/${bookmarkId}`, { method: 'DELETE' })
    get().loadBookmarks(bookId)
  },

  loadHighlights: async (bookId) => {
    const res = await fetch(`${API}/books/${bookId}/highlights`)
    const highlights = await res.json()
    set({ highlights })
  },

  addHighlight: async (bookId, data) => {
    await fetch(`${API}/books/${bookId}/highlights`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
    get().loadHighlights(bookId)
  },

  updateHighlight: async (highlightId, bookId, data) => {
    await fetch(`${API}/highlights/${highlightId}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
    get().loadHighlights(bookId)
  },

  removeHighlight: async (highlightId, bookId) => {
    await fetch(`${API}/highlights/${highlightId}`, { method: 'DELETE' })
    get().loadHighlights(bookId)
  },

  saveProgress: async (bookId, data) => {
    await fetch(`${API}/books/${bookId}/progress`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
  },

  // ── Stats ─────────────────────────────────────────────────────────────────
  stats: null,
  loadStats: async () => {
    const res = await fetch(`${API}/stats`)
    const stats = await res.json()
    set({ stats })
  },

  // ── UI state ──────────────────────────────────────────────────────────────
  sidebarOpen: true,
  readerSidebarTab: null, // 'toc' | 'bookmarks' | 'highlights' | null

  toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen })),
  setReaderSidebarTab: (tab) => set(s => ({ readerSidebarTab: s.readerSidebarTab === tab ? null : tab })),
}))
