import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAppStore } from './store/appStore'
import Layout from './components/Layout'
import HomePage from './components/Home/HomePage'
import LibraryPage from './components/Library/LibraryPage'
import ReaderPage from './components/Reader/ReaderPage'
import SettingsPage from './components/Settings/SettingsPage'
import StatsPage from './components/Stats/StatsPage'

export default function App() {
  const { theme, loadSettings, loadLibraries } = useAppStore()

  useEffect(() => {
    loadSettings()
    loadLibraries()
  }, [])

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="library" element={<LibraryPage />} />
          <Route path="stats" element={<StatsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
        <Route path="/read/:id" element={<ReaderPage />} />
      </Routes>
    </BrowserRouter>
  )
}
