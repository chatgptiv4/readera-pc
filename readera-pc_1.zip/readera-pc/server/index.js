const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// ── Database setup ─────────────────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, '../data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let db;
try {
  const { DatabaseSync } = require('node:sqlite');
  const DB_PATH = path.join(DATA_DIR, 'library.db');
  db = new DatabaseSync(DB_PATH);

  db.exec(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      author TEXT DEFAULT 'Unknown',
      file_path TEXT UNIQUE NOT NULL,
      file_format TEXT NOT NULL,
      file_size INTEGER DEFAULT 0,
      cover_path TEXT,
      total_pages INTEGER DEFAULT 0,
      date_added TEXT DEFAULT (datetime('now')),
      last_opened TEXT,
      is_favourite INTEGER DEFAULT 0,
      reading_status TEXT DEFAULT 'unread'
    );

    CREATE TABLE IF NOT EXISTS reading_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL,
      current_page INTEGER DEFAULT 0,
      current_cfi TEXT,
      scroll_position REAL DEFAULT 0,
      percent_complete REAL DEFAULT 0,
      last_read TEXT DEFAULT (datetime('now')),
      total_read_time INTEGER DEFAULT 0,
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS bookmarks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL,
      page INTEGER,
      cfi TEXT,
      label TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS highlights (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL,
      page INTEGER,
      cfi_range TEXT,
      selected_text TEXT NOT NULL,
      note TEXT,
      color TEXT DEFAULT 'yellow',
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    INSERT OR IGNORE INTO settings VALUES ('watch_folders', '[]');
    INSERT OR IGNORE INTO settings VALUES ('theme', 'dark');
    INSERT OR IGNORE INTO settings VALUES ('font_size', '16');
    INSERT OR IGNORE INTO settings VALUES ('font_family', 'Georgia');
    INSERT OR IGNORE INTO settings VALUES ('daily_goal_pages', '20');
    INSERT OR IGNORE INTO settings VALUES ('anthropic_api_key', '');

    CREATE TABLE IF NOT EXISTS libraries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );
    INSERT OR IGNORE INTO libraries (id, name) VALUES (1, 'My Library');
  `);

  // Migrations for columns added after initial release (safe if already present)
  const bookCols = db.prepare("PRAGMA table_info(books)").all().map(c => c.name);
  if (!bookCols.includes('tags')) db.exec("ALTER TABLE books ADD COLUMN tags TEXT DEFAULT '[]'");
  if (!bookCols.includes('library_id')) db.exec("ALTER TABLE books ADD COLUMN library_id INTEGER DEFAULT 1");
  console.log('✅ Database ready');
} catch (e) {
  console.error('\n❌ Could not start the database:', e.message);
  console.error(`
This app uses Node's built-in SQLite module (node:sqlite), which needs:
  • Node.js 22.5.0 or newer (you have ${process.version})
  • The server started with the --experimental-sqlite flag

If you're running "npm run dev" or "npm run server", that flag is already
included — this error usually means your Node version is too old.
Check with "node -v" and upgrade at https://nodejs.org if needed.
`);
  process.exit(1);
}

// ── Helpers ────────────────────────────────────────────────────────────────
const SUPPORTED_FORMATS = ['.pdf', '.epub', '.mobi', '.txt', '.docx', '.fb2', '.rtf', '.djvu', '.cbz', '.cbr'];

function getFormat(filePath) {
  return path.extname(filePath).toLowerCase();
}

function extractMetaFromPath(filePath) {
  const base = path.basename(filePath, path.extname(filePath));
  const match = base.match(/^(.+?)\s*[-–]\s*(.+)$/);
  if (match) return { author: match[1].trim(), title: match[2].trim() };
  return { author: 'Unknown', title: base };
}

function scanAndAddBook(filePath, libraryId = 1) {
  const ext = getFormat(filePath);
  if (!SUPPORTED_FORMATS.includes(ext)) return;
  if (!fs.existsSync(filePath)) return;

  try {
    const existing = db.prepare('SELECT id FROM books WHERE file_path = ?').get(filePath);
    if (existing) return;
    const stats = fs.statSync(filePath);
    const { author, title } = extractMetaFromPath(filePath);
    db.prepare(`INSERT OR IGNORE INTO books (title, author, file_path, file_format, file_size, library_id) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(title, author, filePath, ext.slice(1).toUpperCase(), stats.size, libraryId || 1);
    console.log(`📚 Added: ${title}`);
  } catch (e) {
    console.error('Error adding book:', e.message);
  }
}

function scanFolder(folderPath, libraryId = 1) {
  if (!fs.existsSync(folderPath)) return;
  const walk = (dir) => {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name.startsWith('.')) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else scanAndAddBook(full, libraryId);
    }
  };
  walk(folderPath);
}

// Init: scan saved folders. Supports both the legacy format (array of path strings)
// and the current format (array of { path, libraryId } objects).
try {
  const savedFolders = JSON.parse(
    db.prepare("SELECT value FROM settings WHERE key = 'watch_folders'").get()?.value || '[]'
  );
  savedFolders.forEach(f => {
    if (typeof f === 'string') scanFolder(f, 1);
    else scanFolder(f.path, f.libraryId || 1);
  });
} catch (e) {}

// ── API Routes ─────────────────────────────────────────────────────────────

// GET all books
app.get('/api/books', (req, res) => {
  try {
    const { search, status, format, sort = 'date_added', order = 'DESC', library_id } = req.query;
    let query = 'SELECT b.*, p.percent_complete, p.last_read FROM books b LEFT JOIN reading_progress p ON b.id = p.book_id WHERE 1=1';
    const params = [];
    if (search) { query += ' AND (b.title LIKE ? OR b.author LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    if (status) { query += ' AND b.reading_status = ?'; params.push(status); }
    if (format) { query += ' AND b.file_format = ?'; params.push(format.toUpperCase()); }
    if (library_id) { query += ' AND b.library_id = ?'; params.push(Number(library_id)); }
    const validSorts = ['date_added', 'title', 'author', 'last_opened', 'percent_complete'];
    const safeSort = validSorts.includes(sort) ? sort : 'date_added';
    query += ` ORDER BY b.${safeSort} ${order === 'ASC' ? 'ASC' : 'DESC'}`;
    res.json(db.prepare(query).all(...params));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET single book
app.get('/api/books/:id', (req, res) => {
  try {
    const book = db.prepare(`
      SELECT b.*, p.current_page, p.percent_complete, p.current_cfi, p.total_read_time
      FROM books b LEFT JOIN reading_progress p ON b.id = p.book_id WHERE b.id = ?
    `).get(req.params.id);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    res.json(book);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// UPDATE book meta
app.put('/api/books/:id', (req, res) => {
  try {
    const { title, author, reading_status, is_favourite } = req.body;
    db.prepare(`UPDATE books SET title = COALESCE(?, title), author = COALESCE(?, author), reading_status = COALESCE(?, reading_status), is_favourite = COALESCE(?, is_favourite) WHERE id = ?`)
      .run(title, author, reading_status, is_favourite, req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE book
app.delete('/api/books/:id', (req, res) => {
  try {
    db.prepare('DELETE FROM books WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// SERVE book file
app.get('/api/books/:id/file', (req, res) => {
  try {
    const book = db.prepare('SELECT * FROM books WHERE id = ?').get(req.params.id);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    if (!fs.existsSync(book.file_path)) return res.status(404).json({ error: 'File not found on disk' });
    db.prepare('UPDATE books SET last_opened = datetime("now") WHERE id = ?').run(book.id);
    res.sendFile(book.file_path);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// SAVE reading progress
app.post('/api/books/:id/progress', (req, res) => {
  try {
    const { current_page, current_cfi, scroll_position, percent_complete, time_delta } = req.body;
    const bookId = req.params.id;
    const existing = db.prepare('SELECT id FROM reading_progress WHERE book_id = ?').get(bookId);
    if (existing) {
      db.prepare(`UPDATE reading_progress SET current_page = COALESCE(?, current_page), current_cfi = COALESCE(?, current_cfi), scroll_position = COALESCE(?, scroll_position), percent_complete = COALESCE(?, percent_complete), total_read_time = total_read_time + COALESCE(?, 0), last_read = datetime('now') WHERE book_id = ?`)
        .run(current_page, current_cfi, scroll_position, percent_complete, time_delta || 0, bookId);
    } else {
      db.prepare(`INSERT INTO reading_progress (book_id, current_page, current_cfi, scroll_position, percent_complete) VALUES (?, ?, ?, ?, ?)`)
        .run(bookId, current_page || 0, current_cfi, scroll_position || 0, percent_complete || 0);
    }
    if (percent_complete >= 95) db.prepare("UPDATE books SET reading_status = 'finished' WHERE id = ?").run(bookId);
    else if (percent_complete > 0) db.prepare("UPDATE books SET reading_status = 'reading' WHERE id = ? AND reading_status = 'unread'").run(bookId);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// BOOKMARKS
app.get('/api/books/:id/bookmarks', (req, res) => {
  try { res.json(db.prepare('SELECT * FROM bookmarks WHERE book_id = ? ORDER BY created_at DESC').all(req.params.id)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/books/:id/bookmarks', (req, res) => {
  try {
    const { page, cfi, label } = req.body;
    const r = db.prepare('INSERT INTO bookmarks (book_id, page, cfi, label) VALUES (?, ?, ?, ?)').run(req.params.id, page, cfi, label || `Page ${page}`);
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.delete('/api/bookmarks/:id', (req, res) => {
  try { db.prepare('DELETE FROM bookmarks WHERE id = ?').run(req.params.id); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// HIGHLIGHTS
app.get('/api/books/:id/highlights', (req, res) => {
  try { res.json(db.prepare('SELECT * FROM highlights WHERE book_id = ? ORDER BY created_at DESC').all(req.params.id)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/books/:id/highlights', (req, res) => {
  try {
    const { page, cfi_range, selected_text, note, color } = req.body;
    const r = db.prepare(`INSERT INTO highlights (book_id, page, cfi_range, selected_text, note, color) VALUES (?, ?, ?, ?, ?, ?)`)
      .run(req.params.id, page, cfi_range, selected_text, note, color || 'yellow');
    res.json({ id: r.lastInsertRowid });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.put('/api/highlights/:id', (req, res) => {
  try {
    const { note, color } = req.body;
    db.prepare('UPDATE highlights SET note = COALESCE(?, note), color = COALESCE(?, color) WHERE id = ?').run(note, color, req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.delete('/api/highlights/:id', (req, res) => {
  try { db.prepare('DELETE FROM highlights WHERE id = ?').run(req.params.id); res.json({ success: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// STATS
app.get('/api/stats', (req, res) => {
  try {
    const total = db.prepare('SELECT COUNT(*) as count FROM books').get().count;
    const finished = db.prepare("SELECT COUNT(*) as count FROM books WHERE reading_status = 'finished'").get().count;
    const reading = db.prepare("SELECT COUNT(*) as count FROM books WHERE reading_status = 'reading'").get().count;
    const totalTime = db.prepare('SELECT SUM(total_read_time) as total FROM reading_progress').get().total || 0;
    const recentBooks = db.prepare(`SELECT b.title, b.author, p.percent_complete, p.last_read FROM books b JOIN reading_progress p ON b.id = p.book_id WHERE p.last_read IS NOT NULL ORDER BY p.last_read DESC LIMIT 5`).all();
    res.json({ total, finished, reading, unread: total - finished - reading, totalReadTime: totalTime, recentBooks });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// SETTINGS
app.get('/api/settings', (req, res) => {
  try {
    const rows = db.prepare('SELECT key, value FROM settings').all();
    const settings = {};
    rows.forEach(r => { try { settings[r.key] = JSON.parse(r.value); } catch { settings[r.key] = r.value; } });
    res.json(settings);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/settings', (req, res) => {
  try {
    const upsert = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    db.exec('BEGIN');
    try {
      for (const [key, val] of Object.entries(req.body)) {
        upsert.run(key, typeof val === 'object' ? JSON.stringify(val) : String(val));
      }
      db.exec('COMMIT');
    } catch (innerErr) {
      db.exec('ROLLBACK');
      throw innerErr;
    }
    if (req.body.watch_folders) {
      req.body.watch_folders.forEach(f => {
        if (typeof f === 'string') scanFolder(f, 1);
        else scanFolder(f.path, f.libraryId || 1);
      });
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// FOLDER BROWSER
app.get('/api/browse', (req, res) => {
  try {
    const dir = req.query.path || os.homedir();
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    const folders = entries
      .filter(e => e.isDirectory() && !e.name.startsWith('.'))
      .map(e => ({ name: e.name, path: path.join(dir, e.name) }));
    res.json({ current: dir, folders, parent: path.dirname(dir) });
  } catch (e) { res.status(400).json({ error: 'Cannot read directory' }); }
});

// SCAN folder on demand
app.post('/api/scan', (req, res) => {
  try {
    const { folder, library_id } = req.body;
    if (!folder) return res.status(400).json({ error: 'No folder provided' });
    scanFolder(folder, Number(library_id) || 1);
    const count = db.prepare('SELECT COUNT(*) as c FROM books').get().c;
    res.json({ success: true, total: count });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Libraries (multi-library support) ───────────────────────────────────────
app.get('/api/libraries', (req, res) => {
  try { res.json(db.prepare('SELECT * FROM libraries ORDER BY id').all()); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/libraries', (req, res) => {
  try {
    const { name } = req.body;
    const r = db.prepare('INSERT INTO libraries (name) VALUES (?)').run(name || 'New Library');
    res.json({ id: r.lastInsertRowid, name });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.delete('/api/libraries/:id', (req, res) => {
  try {
    if (Number(req.params.id) === 1) return res.status(400).json({ error: 'Cannot delete default library' });
    db.prepare('DELETE FROM books WHERE library_id = ?').run(req.params.id);
    db.prepare('DELETE FROM libraries WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/books/:id/library', (req, res) => {
  try {
    const { library_id } = req.body;
    db.prepare('UPDATE books SET library_id = ? WHERE id = ?').run(library_id, req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Tags ─────────────────────────────────────────────────────────────────
app.put('/api/books/:id/tags', (req, res) => {
  try {
    const { tags } = req.body; // array of strings
    db.prepare('UPDATE books SET tags = ? WHERE id = ?').run(JSON.stringify(tags || []), req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/tags', (req, res) => {
  try {
    const rows = db.prepare('SELECT tags FROM books').all();
    const tagSet = new Set();
    rows.forEach(r => { try { JSON.parse(r.tags || '[]').forEach(t => tagSet.add(t)); } catch {} });
    res.json([...tagSet]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Import (file upload) ────────────────────────────────────────────────────
const multer = require('multer');
const IMPORT_DIR = path.join(DATA_DIR, 'imported');
if (!fs.existsSync(IMPORT_DIR)) fs.mkdirSync(IMPORT_DIR, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, IMPORT_DIR),
    filename: (req, file, cb) => cb(null, file.originalname),
  }),
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB
});

app.post('/api/import', upload.array('books'), (req, res) => {
  try {
    const libraryId = Number(req.body.library_id) || 1;
    const added = [];
    (req.files || []).forEach(f => {
      scanAndAddBook(f.path, libraryId);
      added.push(f.originalname);
    });
    res.json({ success: true, added });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Covers (real thumbnails, generated client-side and uploaded here) ──────
const COVERS_DIR = path.join(DATA_DIR, 'covers');
if (!fs.existsSync(COVERS_DIR)) fs.mkdirSync(COVERS_DIR, { recursive: true });
app.use('/api/covers', express.static(COVERS_DIR));

const coverUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

app.post('/api/books/:id/cover', coverUpload.single('cover'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No cover file provided' });
    const filename = `${req.params.id}.jpg`;
    fs.writeFileSync(path.join(COVERS_DIR, filename), req.file.buffer);
    db.prepare('UPDATE books SET cover_path = ? WHERE id = ?').run(filename, req.params.id);
    res.json({ success: true, cover_path: filename });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── AI proxy (summarize / chat with book) ───────────────────────────────────
// Uses the user's own Anthropic API key, stored locally in settings — never hardcoded.
app.post('/api/ai/chat', async (req, res) => {
  try {
    const keyRow = db.prepare("SELECT value FROM settings WHERE key = 'anthropic_api_key'").get();
    const apiKey = keyRow?.value;
    if (!apiKey) return res.status(400).json({ error: 'No Anthropic API key set. Add one in Settings → AI Features.' });

    const { messages, system } = req.body;
    if (typeof fetch !== 'function') {
      return res.status(500).json({ error: 'This server needs Node.js 18+ for built-in fetch support.' });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1024,
        system: system || 'You are a helpful reading assistant.',
        messages: messages || [],
      }),
    });

    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || 'AI request failed' });

    const text = data.content?.find(c => c.type === 'text')?.text || '';
    res.json({ text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n📖  ReadEra PC is running`);
  console.log(`🌐  Open http://localhost:5173 in your browser`);
  console.log(`🔌  API at http://localhost:${PORT}`);
  try {
    console.log(`📚  Library: ${db.prepare('SELECT COUNT(*) as c FROM books').get().c} books\n`);
  } catch (e) {}
});
